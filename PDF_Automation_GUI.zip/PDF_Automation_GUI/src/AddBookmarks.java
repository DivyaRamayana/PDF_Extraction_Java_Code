
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import com.aspose.pdf.Color;
import com.aspose.pdf.Document;
import com.aspose.pdf.DocumentActionCollection;
import com.aspose.pdf.FitHExplicitDestination;
import com.aspose.pdf.GoToAction;
import com.aspose.pdf.License;
import com.aspose.pdf.MarkupParagraph;
import com.aspose.pdf.MarkupSection;
import com.aspose.pdf.OutlineItemCollection;
import com.aspose.pdf.PageMarkup;
import com.aspose.pdf.ParagraphAbsorber;
import com.aspose.pdf.TextFragment;
import com.aspose.pdf.TextFragmentAbsorber;
import com.aspose.pdf.TextFragmentCollection;
import com.aspose.pdf.TextSegment;
import com.aspose.pdf.XYZExplicitDestination;
import com.aspose.pdf.internal.ms.System.Collections.Generic.l0t;

public class AddBookmarks {
	//declare global variables
	public static int count1,count2,ct,par,pageNumber;
	public static String title,GetParentProp,GetChildProp,propsfile,filename,parenttext;

	public static boolean parentSerachbool,childSerachbool;
	public static boolean allreadyAdded = false;
	public static boolean allreadyAdded_ct0 = false;
	public static boolean allreadyAddedNegative = false;

	public static String[] parentkeywords, childkeywords;

	public static Properties prophierarchy = new Properties();

	public static Properties propkeywords = new Properties();

	public static File inputdir, outputdir;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void main(File input_dir, File output_dir) throws Exception {

		inputdir = input_dir;
		outputdir = output_dir;
		//System.out.println("Input directory: "+input_dir + "Output directory: " + output_dir);

		File[] files = input_dir.listFiles();

		for (File f : files) {

			if (f.getName().contains("properties")) {
				propsfile = f.getName();
				//get properties file
				prophierarchy.load(new FileInputStream(input_dir + "\\" + propsfile + "\\Load_hierarchy.properties"));

				propkeywords.load(new FileInputStream(input_dir + "\\" + propsfile + "\\Load_keywords.properties"));
			}

			if (f.getName().contains(".pdf") && f.getName().contains("SpecDoc")) {
				filename = f.getName();

				Document pdfDocument = new Document(inputdir + "\\" + filename);
				
				int index= filename.indexOf(".");
				File csvfile = new File(output_dir+"\\"+filename.substring(0, index)+"_output.csv");
				
				FileWriter outputcsvfile = new FileWriter(csvfile,true);
				
				outputcsvfile.append("Page number");
				outputcsvfile.append(",");
				outputcsvfile.append("Parent keyword");
				outputcsvfile.append(",");
				outputcsvfile.append("Child keyword");
				outputcsvfile.append("\n");
				

				for (Object key : prophierarchy.keySet()) {
					//System.out.println(key + ": " + prophierarchy.getProperty(key.toString()));
					String[] splitfunc = prophierarchy.getProperty(key.toString()).split(",");

					callslipthierarchy(splitfunc);

					callmainmethod(pdfDocument,outputcsvfile);

				}
				
				
				pdfDocument.save(outputdir + "\\" + filename.split("\\.")[0] + "_output.pdf");
				outputcsvfile.flush();
				outputcsvfile.close();
				
				
			}

		}

	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private static void callslipthierarchy(String[] splitfunc) throws Exception 
	{
		for (int i = 0; i < splitfunc.length; i++) 
		{
			GetParentProp = splitfunc[0];
			GetChildProp = splitfunc[1];

		}

		parentkeywords = fetchArrayFromPropFile(GetParentProp, propkeywords);
		childkeywords = fetchArrayFromPropFile(GetChildProp, propkeywords);

	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private static void callmainmethod(Document pdfDocument, FileWriter outputcsvfile) throws Exception 
	{

		OutlineItemCollection testoutline = new OutlineItemCollection(pdfDocument.getOutlines());

		getkeywords(parentkeywords, childkeywords, inputdir, outputdir, filename, pdfDocument, testoutline,outputcsvfile);

	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void getkeywords(String[] parentkeyword, String[] childkeyword, File inputdir, File output_dir,
			String filename, Document pdfDocument, OutlineItemCollection pdfparent_outline, FileWriter outputcsvfile) throws Exception

	{
		
		
		 

		FileInputStream fstream = new FileInputStream(inputdir + "\\" + "Aspose_Lic.lic");
		// Instantiate the License class
		License license = new License();
		// Set the license through the stream object
		license.setLicense(fstream);

		//System.out.println("Licence validated successfully");

		String settile = null;

		for (int k = 0; k < parentkeyword.length; k++) {

			settile = parentkeyword[0];

		}

		pdfparent_outline.setTitle(settile);

		FitHExplicitDestination dest = new FitHExplicitDestination(0, 0);
		
		XYZExplicitDestination dest1 = new XYZExplicitDestination(0, 0, 0, 0);

		ParagraphAbsorber absorber = new ParagraphAbsorber();
		absorber.visit(pdfDocument);
		
		
		for (PageMarkup markup : absorber.getPageMarkups()) {

			count1 = 0;
			count2 = 0;
			ct = 10;
			title = "";
			allreadyAdded = false;
			allreadyAdded_ct0 = false;
			allreadyAddedNegative = false;
			pageNumber = 0;
			par = 0;

			parentSerachbool = false;

			int i = 1;
			for (MarkupSection section : markup.getSections()) {
				int j = 1;
				for (MarkupParagraph paragraph : section.getParagraphs()) {

					for (int k = 0; k < parentkeyword.length; k++) {

						if (paragraph.getText().toLowerCase().contains(parentkeyword[k].toLowerCase())) {
							title = parentkeyword[k];
							

							count1 = i;
							
							
													

							for (l0t<TextFragment> line : paragraph.getLines()) 
							{
								

								for (TextFragment fragment : line) 
								{
									

									for (TextSegment textSegment : (Iterable<TextSegment>) fragment.getSegments()) 
									{	
										if(textSegment.getText().toLowerCase().contains(title.toLowerCase()))
										{
										Color test = Color.getLightBlue();
											
										//textSegment.getTextState().setBackgroundColor(test);
									
										
										// Change foreground color of the first text occurrence
										
										//textSegment.getTextState().setForegroundColor(Color.getDarkBlue());
										
										textSegment.getTextState().setForegroundColor(Color.fromRgb(java.awt.Color.blue));

										textSegment.getTextState().setUnderline(true);
										
										dest = new FitHExplicitDestination(fragment.getPage(),fragment.getPosition().getYIndent());
										
										parenttext = textSegment.getText();
										
										//System.out.println("parent: "+ paragraph.getText());
										
										
										
										//dest1 = new XYZExplicitDestination(fragment.getPage(),fragment.getPosition().getYIndent(),fragment.getPosition().getXIndent(),30);
										}
									}
										//fragment.getTextState().setBackgroundColor(Color.getLightBlue());
										
										par =paragraph.getText().indexOf(title);
									
									

								}

							}

							parentSerachbool = true;
							
							//System.out.println("parent page number: "+ markup.getNumber());
							
						}
					}

					//allreadyAdded=false;
					allreadyAdded_ct0=false;
					
					if (parentSerachbool == true) {
						
												
						for (int l = 0; l < childkeyword.length; l++) {
							
							if (paragraph.getText().toLowerCase().contains(childkeyword[l].toLowerCase()))
							{
								count2 = i;

								ct = count2 - count1;
								
								
								childSerachbool = true;

								if (ct >= 0 && ct < 5) {
									//System.out.println("Bookmark to the page:" + markup.getNumber());
									if (ct == 0) 
									{
										/*System.out.println("Bookmark to the page:" + markup.getNumber());
										System.out.println("--------------------------------------------------------");
										System.out.println("parent index:"+par);
										System.out.println("child index:"+paragraph.getText().indexOf(childkeyword[l]));
										*/
										
										
												
										if(paragraph.getText().indexOf(childkeyword[l])>(par))
										{
											
											
											for (l0t<TextFragment> line : paragraph.getLines()) 
											{
												for (TextFragment fragment : line) 
												{
													//if(fragment.getText().contains(childkeyword[l].toLowerCase()))
													//{
													//fragment.getTextState().setBackgroundColor(Color.getYellow());
													for (TextSegment textSegment : (Iterable<TextSegment>) fragment.getSegments()) 
													{
														if(textSegment.getText().toLowerCase().contains(childkeyword[l].toLowerCase()))
														{
														//textSegment.getTextState().setBackgroundColor(Color.getYellow());
															
															
															
															outputcsvfile.append(Integer.toString(markup.getNumber()));
															outputcsvfile.append(",");
															outputcsvfile.append(parenttext);
															outputcsvfile.append(",");
															outputcsvfile.append(fragment.getText());
															outputcsvfile.append("\n");
															
															TimeUnit.SECONDS.sleep(1);
															
															
															
															System.out.println("Page number : "+markup.getNumber()+" parent_text : "+parenttext+" child_text : "+textSegment.getText());
															
														
															textSegment.getTextState().setForegroundColor(Color.fromRgb(java.awt.Color.yellow));

														textSegment.getTextState().setUnderline(true);
														}
													}
													//}
												}

											}
										
										if(!allreadyAdded_ct0)
										{
										
										OutlineItemCollection pdfChild = new OutlineItemCollection(
												pdfDocument.getOutlines());
										
										pdfChild.setTitle(title + "_Positive");
										pdfChild.setBold(true);
										//System.out.println("line number: "+ i);
										
										/*System.out.println("child page number: "+ markup.getNumber());
										
										System.out.println(" dest: "+ dest);*/
										

										pdfChild.setAction(new GoToAction(dest));
										//pdfChild.setAction(new GoToAction(dest1));

										pdfparent_outline.add(pdfChild);
										}
										
										allreadyAdded_ct0=true;
										}
												
									} 
									
									else if(ct > 0 && ct < 5) 
									{
										

										for (l0t<TextFragment> line : paragraph.getLines()) 
										{
										
											
											
											for (TextFragment fragment : line) 
											{
												for (TextSegment textSegment : (Iterable<TextSegment>) fragment.getSegments()) 
												{
													if(textSegment.getText().toLowerCase().contains(childkeyword[l].toLowerCase()))
													{
												//fragment.getTextState().setBackgroundColor(Color.getLightGreen());
													//textSegment.getTextState().setBackgroundColor(Color.getLightGreen());
														
														outputcsvfile.append(Integer.toString(markup.getNumber()));
														outputcsvfile.append(",");
														outputcsvfile.append(parenttext);
														outputcsvfile.append(",");
														outputcsvfile.append(fragment.getText());
														outputcsvfile.append("\n");
														
														TimeUnit.SECONDS.sleep(1);
														
														System.out.println("Page number : "+markup.getNumber()+" parent_text : "+parenttext+" child_text : "+textSegment.getText());
														
													
														textSegment.getTextState().setForegroundColor(Color.fromRgb(java.awt.Color.green));

													textSegment.getTextState().setUnderline(true);
													}
												}
												
											}

										}
										
										
										if(!allreadyAdded)
										{
										
										OutlineItemCollection pdfChild = new OutlineItemCollection(
												pdfDocument.getOutlines());
										
										pdfChild.setTitle(title + "_Positive");
										pdfChild.setBold(true);
										//System.out.println("line number: "+ i);
										
										
										/*System.out.println("child page number: "+ markup.getNumber());
										
										System.out.println(" dest: "+ dest);*/
										

										pdfChild.setAction(new GoToAction(dest));
										//pdfChild.setAction(new GoToAction(dest1));

										pdfparent_outline.add(pdfChild);
										}
										
										allreadyAdded=true;
									}

									
									

								}

								

							}
							
							else
							{
								
								if(!allreadyAddedNegative)
								{
								
								//System.out.println(title + "_Negative");
								pageNumber = markup.getNumber();
								OutlineItemCollection pdfChild = new OutlineItemCollection(
										pdfDocument.getOutlines());
								pdfChild.setTitle(title + "_Negative");

								//System.out.println("Destination :- " + dest);

								//System.out.println(markup.getNumber());
								pdfChild.setAction(new GoToAction(dest));
								//pdfChild.setAction(new GoToAction(dest1));
								pdfparent_outline.add(pdfChild);
								}
								
								allreadyAddedNegative = true;
							}
							
							
							
						

						}

					}

					j++;
				}
				i++;
			}

			pdfDocument.getOutlines().add(pdfparent_outline);
			

		}
		
		
		

	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	private static String[] fetchArrayFromPropFile(String propertyName, Properties prop) {

		String[] a = prop.getProperty(propertyName).split(",");

		//System.out.println(propertyName);

		String[] array = new String[a.length];

		for (int i = 0; i < a.length; i++) {
			array[i] = a[i];
			// System.out.println(a[i]);
		}
		return array;
	}

}
