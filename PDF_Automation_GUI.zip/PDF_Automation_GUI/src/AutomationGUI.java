import java.awt.BorderLayout;

import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AutomationGUI {

	static DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
	static Date dateobj = new Date();
	static String date = df.format(dateobj);

	static Calendar cal = Calendar.getInstance();
	static SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss");
	static String time = tf.format(cal.getTime());

	public static File input_dir, output_dir;

	public static Boolean inpflg, outflg;

	public static JTextField txtPath,txtPath1;

	public static void main(String[] args) throws InterruptedException {
		createWindow();
	}

	private static void createWindow() throws InterruptedException {
		JFrame frame = new JFrame("PDF_Automation_Testing_Tool" + "    Date: " + date + "   Time: " + time);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

		createUI(frame);
		frame.setSize(560, 200);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {

				int result1 = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Warning Message",
						JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);

				if (result1 == JOptionPane.YES_OPTION) {
					JOptionPane.showConfirmDialog(null, "Saved changes", "Message", JOptionPane.CLOSED_OPTION,
							JOptionPane.INFORMATION_MESSAGE);
					System.exit(0);

				}
			}

		});
	}

	private static void createUI(final JFrame frame) throws InterruptedException {
		JPanel panel = new JPanel();
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		LayoutManager layout = new FlowLayout();
		panel.setLayout(layout);

		JButton button = new JButton("Browse Input_Dir");
		button.setBounds(10, 41, 87, 23);
		final JLabel label = new JLabel();
		final JLabel label1 = new JLabel();

		txtPath = new JTextField();
		txtPath.setBounds(10, 10, 414, 21);
		txtPath.setColumns(30);

		txtPath1 = new JTextField();
		txtPath1.setBounds(10, 10, 414, 21);
		txtPath1.setColumns(30);

		JButton button1 = new JButton("Browse Output_Dir");
		button1.setBounds(10, 41, 87, 23);

		JButton button2 = new JButton("Load files");
		button1.setBounds(10, 41, 87, 23);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();

				fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				fileChooser.setAcceptAllFileFilterUsed(false);

				int rVal = fileChooser.showOpenDialog(null);
				if (rVal == JFileChooser.APPROVE_OPTION) {

					input_dir = fileChooser.getSelectedFile();

					inpflg = true;
					txtPath.setText(fileChooser.getSelectedFile().toString());

				}
			}
		});

		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();

				fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

				fileChooser.setAcceptAllFileFilterUsed(false);

				int rVal = fileChooser.showOpenDialog(null);
				if (rVal == JFileChooser.APPROVE_OPTION) {

					txtPath1.setText(fileChooser.getSelectedFile().toString());

					output_dir = fileChooser.getSelectedFile();

					outflg = true;

				}
			}

		});

		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (inpflg == true && outflg == true) {

					try {
						AddBookmarks.main(input_dir, output_dir);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				label1.setText("Files Bookmarked successfully..!!");
			}

		});

		panel.add(txtPath);
		panel.add(button);

		panel1.add(txtPath1);
		panel1.add(button1);

		panel.add(panel1);

		panel2.add(button2);
		panel.add(panel2);

		panel3.add(label1);

		panel.add(panel3);

		frame.getContentPane().add(panel, BorderLayout.CENTER);

	}

}
